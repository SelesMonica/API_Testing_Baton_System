﻿using System.Security.Cryptography;

namespace TU.DE.Specflow.ApiModels
{
    public class DocumentUpload
    {
        public string Description { get; set; } = "IDDocument";
        public string FileName { get; set; } = "UMID2.jpg";
        public string Note { get; set; } = "Test";
        public byte[] ImageByteArray { get; set; }
    }
}
