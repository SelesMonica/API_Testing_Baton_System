﻿using Newtonsoft.Json;
namespace Specflow.ApiModels
{
    public partial class AuthendicateModel
    {
        [JsonProperty("error")]
        public string Error { get; set; }

        [JsonProperty("error_description")]
        public string ErrorDescription { get; set; }
    }
    public partial class AuthendicateModel
    {

        [JsonProperty("expires_in")]
        public long ExpiresIn { get; set; }

        [JsonProperty("userId")]
        public string UserName { get; set; }

        [JsonProperty(".issued")]
        public string Issued { get; set; }

        [JsonProperty(".expires")]
        public string Expires { get; set; }
    }
    public partial class AuthendicateModel
    {
        [JsonProperty("Message")]
        public string Message { get; set; }
    }
}
