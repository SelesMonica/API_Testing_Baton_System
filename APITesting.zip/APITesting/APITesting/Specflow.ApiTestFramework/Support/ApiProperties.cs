﻿using TU.DE.Specflow.ApiModels;

namespace TU.DE.Specflow.ApiTestFramework.Support
{
    public class ApiProperties
    {
        private PontRequestModel _requestmodel;
        private PontResponsetModel _responsemodel;

        public PontRequestModel TUJsonRequestModel
        {
            get
            {
                if (this._requestmodel == null)
                {
                    return this._requestmodel = new PontRequestModel();
                }
                else
                {
                    return this._requestmodel;
                }
            }
        }

        public PontResponsetModel TUJsonResponseModel
        {
            get
            {
                if (this._responsemodel == null)
                {
                    return this._responsemodel = new PontResponsetModel();
                }
                else
                {
                    return this._responsemodel;
                }
            }
        }

        public string AccessToken
        {
            get;
            set;
        }
    }
}