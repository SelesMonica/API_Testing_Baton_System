﻿using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Cache;
using System.Net.Http;
using System.Net.Security;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;
using Specflow.HelperUtilities;

namespace Specflow.ApiTestFramework.ExternalService
{
    public static class PontServiceConnector
    {
        #region JSON
        private static void ChangeTlsType()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls |
                                                   SecurityProtocolType.Tls11 |
                                                   SecurityProtocolType.Tls12;
            ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) =>
            {
                return true;
            };
        }


        //GET Method 

        public static IRestResponse GetMethodRequest(string URL, string AuthToken)
        {
            ChangeTlsType();

            var client = new RestClient(URL)
            {
                Authenticator = new OAuth2AuthorizationRequestHeaderAuthenticator(AuthToken, "bearer")
            };
            var request = new RestRequest(Method.GET)
            {
                RequestFormat = DataFormat.Json,
                Timeout = int.MaxValue,
                UseDefaultCredentials = true,

            };

            return client.Execute(request);
        }


         // POST Method
        public static IRestResponse PostMethodWithJSONRequestBody<T>(string URL, string AuthToken, T Content)
        {
            ChangeTlsType();
            var client = new RestClient(URL)
            {
                Authenticator = new OAuth2AuthorizationRequestHeaderAuthenticator(AuthToken, "bearer")
            };
            var request = new RestRequest(Method.POST)
            {
                RequestFormat = DataFormat.Json,
                Timeout = int.MaxValue,
                UseDefaultCredentials = true,
            };
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", AuthToken);
            if (Content != null)
            {
                var jBody = JsonHelper.SerializeToJson(Content);
                request.AddParameter("application/json", jBody, ParameterType.RequestBody);
            }
            return client.Execute(request);
        }

        // PUT Method
        public static IRestResponse PutMethodWithJSONRequestBody<T>(string URL, string AuthToken, T Content)
        {
            ChangeTlsType();
            var client = new RestClient(URL)
            {
                Authenticator = new OAuth2AuthorizationRequestHeaderAuthenticator(AuthToken, "bearer")
            };
            var request = new RestRequest(Method.PUT)
            {
                RequestFormat = DataFormat.Json,
                Timeout = int.MaxValue,
                UseDefaultCredentials = true,
            };
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", AuthToken);
            if (Content != null)
            {
                var jBody = JsonHelper.SerializeToJson(Content);
                request.AddParameter("application/json", jBody, ParameterType.RequestBody);
            }
            return client.Execute(request);
        }

        // PATCH Method
        public static IRestResponse PatchMethodWithJSONRequestBody<T>(string URL, string AuthToken, T Content)
        {
            ChangeTlsType();
            var client = new RestClient(URL)
            {
                Authenticator = new OAuth2AuthorizationRequestHeaderAuthenticator(AuthToken, "bearer")
            };
            var request = new RestRequest(Method.PATCH)
            {
                RequestFormat = DataFormat.Json,
                Timeout = int.MaxValue,
                UseDefaultCredentials = true,
            };
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", AuthToken);
            if (Content != null)
            {
                var jBody = JsonHelper.SerializeToJson(Content);
                request.AddParameter("application/json", jBody, ParameterType.RequestBody);
            }
            return client.Execute(request);
        }

        // DELETE Method
        public static IRestResponse DeleteMethodWithJSONRequestBody<T>(string URL, string AuthToken, T Content)
        {
            ChangeTlsType();
            var client = new RestClient(URL)
            {
                Authenticator = new OAuth2AuthorizationRequestHeaderAuthenticator(AuthToken, "bearer")
            };
            var request = new RestRequest(Method.DELETE)
            {
                RequestFormat = DataFormat.Json,
                Timeout = int.MaxValue,
                UseDefaultCredentials = true,
            };
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", AuthToken);
            if (Content != null)
            {
                var jBody = JsonHelper.SerializeToJson(Content);
                request.AddParameter("application/json", jBody, ParameterType.RequestBody);
            }
            return client.Execute(request);
        }


        #endregion
        public static bool Is200OkResponse(IRestResponse response)
        {
            return response.IsSuccessful;
        }
        public static bool Is201CreatedResponse(IRestResponse response)
        {
            return response.IsSuccessful;
        }
    }
}
