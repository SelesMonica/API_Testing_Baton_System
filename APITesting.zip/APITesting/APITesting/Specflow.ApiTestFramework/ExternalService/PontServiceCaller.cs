﻿using System;
using System.Net;
using Specflow.HelperUtilities;
using Specflow.ApiModels;
using RestSharp;

namespace ApiTestFramework.ExternalService
{
    public class PontServiceCaller
    {
        private string Token = string.Empty;
        

        private AuthendicateModel GetObjectFromJsonString(string JsonString)
        {
            return JsonHelper.DeserializeFromJson<AuthendicateModel>(JsonString);
        }
        public string GenerateAccessToken()
        {
            try
            {
                if (string.IsNullOrEmpty(this.Token))
                {
                    var result = PontServiceConnector.PostMethodWithRequestBody(Environment.Specflow.Variables.Env_PontServiceTokenURL, "grant_type=password&username=" + Environment.Specflow.Variables.Env_ApiUserId + "&password=" + Environment.Specflow.Variables.Env_ApiPassword);
                    if (result != null && result.StatusCode == HttpStatusCode.OK)
                    {
                        this.Token = GetObjectFromJsonString(result.Content).AccessToken;
                    }
                    else if (result != null && result.StatusCode == HttpStatusCode.BadRequest)
                    {
                        throw new TUSpecflowPartialException(GetObjectFromJsonString(result.Content).ErrorDescription);
                    }
                }
            }
            catch (TUSpecflowPartialException ex)
            {
                throw ex;
            }
            return this.Token;
        }
        public PontResponsetModel Post(PontRequestModel pontRequestModel, EndPointType endPointType, string Id = null)
        {
            PontResponsetModel pontResponsetModel = new PontResponsetModel();
            try
            {
                string Url = null;
                IRestResponse Response = null;
                if (endPointType == EndPointType.Login)
                {
                    Url = Environment.Specflow.Variables.Env_PortalLogin;
                    Response = PontServiceConnector.PostMethodWithJSONRequestBody(Url, GenerateAccessToken(), pontRequestModel);
                }
                else if (endPointType == EndPointType.Register)
                {
                    Url = Environment.Specflow.Variables.Env_PortalRegister;
                    Response = PontServiceConnector.PostMethodWithJSONRequestBody(Url, GenerateAccessToken(), pontRequestModel);
                }
                else if (endPointType == EndPointType.Create)
                {
                    Url = Environment.Specflow.Variables.Env_PortalUser;
                    Response = PontServiceConnector.PostMethodWithJSONRequestBody(Url, GenerateAccessToken(), Id);
                }
                else if (endPointType == EndPointType.Create)
                {
                    Url = Environment.Specflow.Variables.Env_PortalCreate;
                    Response = PontServiceConnector.PostMethodWithPlainTextRequestBody(Url, GenerateAccessToken(), image.ImageByteArray);
                }
                else if (endPointType == EndPointType.Delete)
                {
                    Url = Environment.Specflow.Variables.Env_PontUploadDocumentURL.Replace("{{Id}}", Id);
                    Response = PontServiceConnector.PostMethodWithPlainTextRequestBody(Url, GenerateAccessToken(), image.ImageByteArray);
                }


                else if (Response != null && Response.StatusCode == HttpStatusCode.BadRequest)
                {
                    if (GetObjectFromJsonString(Response.Content).ErrorDescription != null)
                        throw new SpecflowPartialException(GetObjectFromJsonString(Response.Content).ErrorDescription);
                    else if (GetObjectFromJsonString(Response.Content).Message != null)
                        throw new SpecflowPartialException(GetObjectFromJsonString(Response.Content).Message);
                }
                else if (!string.IsNullOrEmpty(Response.ErrorMessage))
                {
                    pontResponsetModel.Message = Response.ErrorMessage;
                }
            }
            catch (TUSpecflowPartialException ex)
            {
                throw ex;
            }
            return pontResponsetModel;
        }
    }
}
