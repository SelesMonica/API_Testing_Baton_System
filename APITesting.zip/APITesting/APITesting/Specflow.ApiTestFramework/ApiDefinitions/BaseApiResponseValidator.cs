﻿/*
 *  This is partial class with the name of DCExternalApi and its having all common response validation functions
 *  In future, if you find any resuable functions, add it here. it can be reused
 */

using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using Specflow.ApiModels;
using Specflow.ApiTestFramework.ExternalService;
using Specflow.ApiTestFramework.Support;
using Specflow.HelperUtilities;

namespace Specflow.ApiTestFramework.ApiDefinitions
{
    public partial class DCExternalApi : ApiProperties
    {
        private readonly PontServiceCaller pontServiceCaller;

        // Object instance creation in constructor
        public DCExternalApi()
        {
            pontServiceCaller = new PontServiceCaller();
        }

        #region Generic function

        protected void Pont_GenerateAccessToken()
        {
            AccessToken = pontServiceCaller.GenerateAccessToken();
        }

        protected void Pont_Response_CheckAuthTokenIsGenerated(bool IsValidTokenExpected = true)
        {
            if (IsValidTokenExpected && string.IsNullOrEmpty(AccessToken))
            {
                throw new SpecflowPartialException("Access token is empty or null. But the expectation is to be generated");
            }
            else if ((!IsValidTokenExpected) && (!string.IsNullOrEmpty(AccessToken)))
            {
                throw new SpecflowPartialException("Access token is generated. But the expectation is not to be generated");
            }
        }


        protected void Pont_Response_Resources_List(string id, string name, string year, string color)
        {
            if (JsonResponseModel.id != null && JsonResponseModel.id.name != null && JsonResponseModel.id.name.year != null && JsonResponseModel.id.name.year.color != null)
            {
                var Errors = JsonResponseModel.id.name.year.color.Where(t => (t.Code == ErrorCode && t.Message == ErrorMessage) || (t.ErrorCode == ErrorCode && t.ErrorMessage == ErrorMessage)).FirstOrDefault();
                if (Errors == null)
                {
                    throw new SpecflowPartialException("Gievn error code and message not found in ApplicaitonData_IO");
                }
            }
            else
            {
                throw new SpecflowPartialException("Gievn error code and message not found in ApplicaitonData_IO");
            }
        }

        protected void Pont_Response_CheckApiCallIsSuccess(bool ExpectedStatus = true)
        {
            if (ExpectedStatus)
            {
                if (JsonResponseModel != null)
                {
                    if (JsonResponseModel.Status != "Success")
                    {
                        if (string.IsNullOrEmpty(JsonResponseModel.Message))
                        {
                            throw new SpecflowPartialException("Api Call is failed. But the expectation is to be success");
                        }
                        else
                        {
                            throw new SpecflowPartialException("Api Call is failed. But the expectation is to be success. Error is - " + JsonResponseModel.Message);
                        }
                    }
                }
                else
                {
                    throw new SpecflowPartialException("Api Call is failed. But the expectation is to be success");
                }
            }
            else
            {
                if (JsonResponseModel != null)
                {
                    if (JsonResponseModel.Status == "Success")
                    {
                        throw new SpecflowPartialException("Api Call is Success. But the expectation is to be Fail");
                    }
                }
            }
        }

        protected void APIRequest_RegisterUnsuccessful(string email)
        {
            if (JsonResponseModel != null && JsonResponseModel.email != null && JsonResponseModel.email.password !=null)
            {
                foreach (var App in JsonResponseModel.email.password)
                {
                    if (App.email != null)
                    {
                        if (ExpectedIsSuccess != "N/A" && App.email.IsSuccess != ExpectedIsSuccess)
                        {
                            throw new SpecflowPartialException("email is not expected. The expected value is '" + ExpectedIsSuccess + "' the actual value is '" + App.email.IsSuccess + "'");
                        }
                        if (ExpectedIsSuccess != "N/A" && App.email.password.IsSuccess != ExpectedIsSuccess)
                        {
                            throw new SpecflowPartialException("password is not expected. The expected value is '" + ExpectedIsSuccess + "' the actual value is '" + App.email.password.IsSuccess + "'");
                        }
                       
                    }
                }
            }
        }

        protected void APIRequest_RegisterUnsuccessful_errormessage(string email)
        {
            if (JsonResponseModel != null && JsonResponseModel.email != null && JsonResponseModel.email.password != null)
            {
                foreach (var App in JsonResponseModel.email.password)
                {
                    if (App.email.password != null)
                    {
                        if (ExpectedErrorMessage != "N/A" && App.email.password.ErrorMessage != ExpectedErrorMessage)
                        {
                            throw new SpecflowPartialException("Missing Password" + ExpectedErrorMessage + "' the actual value is '" + App.email.password.ErrorMessage + "'");
                        }
                        else if (ExpectedErrorCode != "N/A" && App.email.password.ErrorMessage != ExpectedErrorcode)
                        {
                            throw new SpecflowPartialException("400" + ExpectedErrorcode + "' the actual value is '" + App.email.password.Errorcode + "'");
                        }

                    }
                }
            }
        }


        protected void APIRequest_LoginUnsuccessful(string email)
        {
            if (JsonResponseModel != null && JsonResponseModel.email != null && JsonResponseModel.email.password != null)
            {
                foreach (var App in JsonResponseModel.email.password)
                {
                    if (App.email != null)
                    {
                        if (ExpectedIsSuccess != "N/A" && App.email.IsSuccess != ExpectedIsSuccess)
                        {
                            throw new SpecflowPartialException("email is not expected. The expected value is '" + ExpectedIsSuccess + "' the actual value is '" + App.email.IsSuccess + "'");
                        }
                        if (ExpectedIsSuccess != "N/A" && App.email.password.IsSuccess != ExpectedIsSuccess)
                        {
                            throw new SpecflowPartialException("password is not expected. The expected value is '" + ExpectedIsSuccess + "' the actual value is '" + App.email.password.IsSuccess + "'");
                        }

                    }
                }
            }
        }

        protected void APIRequest_LoginUnsuccessful_errormessage(string email)
        {
            if (JsonResponseModel != null && JsonResponseModel.email != null && JsonResponseModel.email.password != null)
            {
                foreach (var App in JsonResponseModel.email.password)
                {
                    if (App.email.password != null)
                    {
                        if (ExpectedErrorMessage != "N/A" && App.email.password.ErrorMessage != ExpectedErrorMessage)
                        {
                            throw new SpecflowPartialException("Missing Password" + ExpectedErrorMessage + "' the actual value is '" + App.email.password.ErrorMessage + "'");
                        }
                        else if (ExpectedErrorCode != "N/A" && App.email.password.ErrorMessage != ExpectedErrorcode)
                        {
                            throw new SpecflowPartialException("400" + ExpectedErrorcode + "' the actual value is '" + App.email.password.Errorcode + "'");
                        }

                    }
                }
            }
        }

    }
}