﻿/*
 *  This is partial class with the name of "DCExternalApi" and its having all common API request builder functions
 *  In future, if you find any resuable functions, add it here. it can be reused
 */

using System;
using System.Collections.Generic;
using System.Linq;
using Specflow.ApiModels;
using Specflow.ApiTestFramework.Support;
using Specflow.HelperUtilities;

namespace Specflow.ApiTestFramework.ApiDefinitions
{
    public partial class DCExternalApi : ApiProperties
    {
        protected void ReadDefaultApplicantsDataFromTemplateJson()
        {
            var strAppData = JsonHelper.BeginReadFile(@"TemplateData\RequestData.json");
            var TempResponse = JsonHelper.DeserializeFromJson<PontRequestModel>(strAppData);
            if (TempResponse != null)
            {
                JsonRequestModel.id = TempResponse.id;
                JsonRequestModel.email = TempResponse.email;
                JsonRequestModel.first_name = TempResponse.first_name;
                JsonRequestModel.last_name = TempResponse.last_name;


            }
        }

        protected void APIRequestShowingUser(string Id, string email, string First_Name, string Last_Name)
            {
                if (JsonRequestModel != null && JsonRequestModel.id != null && JsonRequestModel.id.email != null && JsonRequestModel.id.email.first_name != null && JsonRequestModel.id.email.last_name > 0)
                {
                    foreach (var App in JsonRequestModel.id.email.first_name)
                    {
                        if (App.first_name != null)
                        {
                            App.first_name = (FirstName == "N/A" ? string.Empty : first_name);
                        }
                        else
                        {
                            throw new SpecflowPartialException("User Details Not found");
                        }
                        if (App.last_name != null)
                        {
                            App.last_name = (LastName == "N/A" ? string.Empty : first_name);
                        }
                        else
                        {
                            throw new SpecflowPartialException("User Details Not found");
                        }
                    }
                }




        protected void APIRequestShowingList(string Id, string email, string First_Name, string Last_Name)
        {
            if (JsonRequestModel != null && JsonRequestModel.id != null && JsonRequestModel.id.email != null && JsonRequestModel.id.email.first_name != null && JsonRequestModel.id.email.last_name > 0)
            {
                foreach (var App in JsonRequestModel.id.email.first_name)
                {
                    if (App.first_name != null)
                    {
                        App.first_name = (FirstName == "N/A" ? string.Empty : first_name);
                    }
                    else
                    {
                        throw new SpecflowPartialException("User Details Not found");
                    }
                    if (App.last_name != null)
                    {
                        App.last_name = (LastName == "N/A" ? string.Empty : first_name);
                    }
                    else
                    {
                        throw new SpecflowPartialException("User Details Not found ");
                    }
                }
            }
        }


                protected void Pont_Response_Resources_List(string Id, string email, string First_Name, string Last_Name)
                {
                    if (JsonRequestModel != null && JsonRequestModel.id != null && JsonRequestModel.id.email != null && JsonRequestModel.id.email.first_name != null && JsonRequestModel.id.email.last_name > 0)
                    {
                        foreach (var App in JsonRequestModel.id.email.first_name)
                        {
                            if (App.first_name != null)
                            {
                                App.first_name = (FirstName == "N/A" ? string.Empty : first_name);
                            }
                            else
                            {
                                throw new SpecflowPartialException("User Details Not found");
                            }
                            if (App.last_name != null)
                            {
                                App.last_name = (LastName == "N/A" ? string.Empty : first_name);
                            }
                            else
                            {
                                throw new SpecflowPartialException("User Details Not found");
                            }
                        }
                    }




                    protected void Pont_Response_Resources_Detail(string Id, string email, string First_Name, string Last_Name)
                    {
                        if (JsonRequestModel != null && JsonRequestModel.id != null && JsonRequestModel.id.email != null && JsonRequestModel.id.email.first_name != null && JsonRequestModel.id.email.last_name > 0)
                        {
                            foreach (var App in JsonRequestModel.id.email.first_name)
                            {
                                if (App.first_name != null)
                                {
                                    App.first_name = (FirstName == "N/A" ? string.Empty : first_name);
                                }
                                else
                                {
                                    throw new SpecflowPartialException("User Details Not found");
                                }
                                if (App.last_name != null)
                                {
                                    App.last_name = (LastName == "N/A" ? string.Empty : first_name);
                                }
                                else
                                {
                                    throw new SpecflowPartialException("User Details Not found ");
                                }
                            }
                        }
                    }

                    protected void APIRequest_nameandjob(string name, string job)
                    {
                        if (JsonRequestModel != null && JsonRequestModel.name != null && JsonRequestModel.name.job ! > 0)
                        {
                            foreach (var App in JsonRequestModel.name.job)
                            {
                                if (App.name != null && App.name.job > 0)
                                {
                                    App.name.job.ForEach(t => t.Value = (name == "EMPTY" ? "" : name));
                                }
                                else
                                {
                                    throw new TUSpecflowPartialException("no name found");
                                }
                            }
                        }
                        else
                        {
                            throw new TUSpecflowPartialException("no job found");
                        }
                    }


                    
                          protected void APIRequest_updatenameandjob(string name, string job)
                    {
                        if (JsonRequestModel != null && JsonRequestModel.name != null && JsonRequestModel.name.job! > 0)
                        {
                            foreach (var App in JsonRequestModel.name.job)
                            {
                                if (App.name != null && App.name.job > 0)
                                {
                                    App.name.job.ForEach(t => t.Value = (name == "EMPTY" ? "" : name));
                                }
                                else
                                {
                                    throw new SpecflowPartialException("no name found");
                                }
                            }
                        }
                        else
                        {
                            throw new SpecflowPartialException("no job found");
                        }
                    }

                    protected void APIRequest_RegisterUser(string email, string password)
                    {
                        if (JsonRequestModel.RequestInfo == null)
                        {
                            JsonRequestModel.RequestInfo = new RequestInfo();
                        }

                        if (email == "<email>")
                            email = Environment.ReadEnvironmentVariables("email");
                        if (password == "<password>")
                            password = Environment.ReadEnvironmentVariables("password");

                     
                        JsonRequestModel.RequestInfo.email = email;
                        JsonRequestModel.RequestInfo.password = password;
                        //TUJsonRequestModel.RequestInfo.ExecuteLatestVersion = "true";
                        //TUJsonRequestModel.RequestInfo.ExecutionMode = "NewWithContext";
                        var TempTUJsonRequestModel = pontServiceCaller.Post(JsonRequestModel, EndPointType.Register);
                        if (TempTUJsonRequestModel != null)
                        {
                            JsonResponseModel.id = TempJsonRequestModel.id;
                            JsonResponseModel.token = TempJsonRequestModel.token;
                            if (!string.IsNullOrEmpty(TempJsonRequestModel.Message))
                                TUJsonResponseModel.Message = TempTUJsonRequestModel.Message;
                        }
                    }


                protected void APIResponseDelay(int sleepTime)
                {
                    int sleepTime = 1000; // in mills
                    Task.Delay(sleepTime).Wait();

                          }







                }
            }