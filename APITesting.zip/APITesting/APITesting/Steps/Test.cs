﻿
using System;
using TechTalk.SpecFlow;
using Specflow.ApiTestFramework.ApiDefinitions;

namespace Specflow.TestSuiteApi.StepDefinition
{
    [Binding]
    public sealed class Test : DCExternalApi
    {
      
        [Obsolete("")]
        [AfterStep]
        private void LogAppId()
        {
            var AppId = string.Empty;
            if (TUJsonResponseModel != null && TUJsonResponseModel.ResponseInfo != null)
            {
                AppId = TUJsonResponseModel.ResponseInfo.ApplicationId;
            }
            if (!string.IsNullOrEmpty(AppId))
                Console.WriteLine($"APPID[" + AppId + "]APPID");
        }

        #region Genric 

        [Given(@"Using Username and Password Generate the Access Token \(read the UserId and Password from App Config file\)")]
        public void GivenUsingUsernameAndPasswordGenerateTheAccessTokenReadTheUserIdAndPasswordFromAppConfigFile()
        {
            //Skip the Step
        }

        [When(@"I POST a GET Access Token JSON request")]
        public void WhenIPOSTAGETAccessTokenJSONRequest()
        {
            Pont_GenerateAccessToken();
        }

        [When(@"I POST Queue Resume JSON request from Service Input Queue for microservice")]
        public void WhenIPOSTQueueResumeJSONRequestFromServiceInputQueueForMicroservice()
        {
            Pont_Request_QueueResumeApplication();
        }


        [When(@"I expect a valid authentication token")]
        public void WhenIExpectAValidAuthenticationToken()
        {
            Pont_Response_CheckAuthTokenIsGenerated(true);
        }

        [Given(@"Read Default Applicant Data")]
        public void GivenReadDefaultApplicantData()
        {
            ReadDefaultApplicantsDataFromTemplateJson();
        }

        [Given(@"Read the Default JSON Request Data from Template file")]
        public void GivenReadTheDefaultJSONRequestDataFromTemplateFile()
        {
            ReadDefaultApplicantsDataFromTemplateJson();
        }

      
        [Given(@"display the user details")]
        public void GivenDisplayTheUserDetails(string Id, string email, string First_Name, string Last_Name)
        {
            APIRequestShowingUser(Id, email, First_Name, Last_Name);
        }

        [Given(@"display all the user details with the list")]
        public void GivenDisplayAllTheUserDetailsWithTheList(string Id, string email, string First_Name, string Last_Name)
        {
            APIRequestShowingList(Id, email, First_Name, Last_Name);
        }


         

      

        [Then(@"I expect a success response")]
        public void ThenIExpectASuccessResponse()
        {
            Pont_Response_CheckApiCallIsSuccess(true);
        }

          

         
        [Then(@"the list of the resources should be displayed")]
        public void ThenTheListOfTheResourcesShouldBeDisplayed(string id, string name, string year, string color)
        {
            Pont_Response_Resources_List(id, name, year, color);

        }

        [Then(@"check whether single details can fetch from the page")]
        public void ThenCheckWhetherSingleDetailsCanFetchFromThePage(string id, string name, string year, string color)
        {
            Pont_Response_Resources_Detail(id, name, year, color);
        }

        [Given(@"create a new user with the (.*) and (.*)")]
        public void GivenCreateANewUserWithTheAnd(string name, string job)
        {
           APIRequest_nameandjob(name, job);
        }


        [Given(@"update the user details (.*) and (.*)")]
        public void GivenUpdateTheUserDetailsAnd(string name, string job)
        {
            APIRequest_updatenameandjob(name, job);
        }


        [Given(@"delete the existing user")]
        public void GivenDeleteTheExistingUser()
        {
            APIRequest_deleteuser();
        }

        [Given(@"enter the email address (.*) and password (.*)")]
        public void GivenEnterTheEmailAddressAndPassword(string email, string password)
        {
            APIRequest_RegisterUser(email, password);
        }

        [Given(@"enter the email address (.*)")]
        public void GivenEnterTheEmailAddress(string email)
        {
            APIRequest_RegisterUnsuccessful(email);

        }
        [Then(@"I expect error to be returned with the error message (.*)")]
        public void ThenIExpectErrorToBeReturnedWithTheErrorMessage(string error)
        {
            APIRequest_RegisterUnsuccessful_errormessage(error);
        }
        [Given(@"Using Username and Password Generate the Access Token (.*) (.*)")]
        public void GivenUsingUsernameAndPasswordGenerateTheAccessToken(string email, string password)
        {
            GenerateAccessToken(email, password);
        }

        [When(@"I expect delay in response")]
        public void WhenIExpectDelayInResponse(int sleepTime)
        {
            APIResponseDelay(sleepTime);
        }








    }



}