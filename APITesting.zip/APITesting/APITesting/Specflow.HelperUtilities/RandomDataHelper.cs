﻿/*
 * this class is used to generate the random data
 * it can be used anywhere
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TU.DE.Specflow.HelperUtilities
{
    public class RandomDataHelper
    {
        private readonly Random rnd;

        public RandomDataHelper()
        {
            rnd = new Random();
        }

        private readonly char[] AlphaNumericCharacters = @"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
        private readonly char[] PunctuationCharacters = @"~`!@#$%^&*()_+=-|[{]}:/?.>,<".ToCharArray();

        public string GetDateDDMMYYYY()
        {
            DateTime start = new DateTime(1995, 1, 1);
            int range = (DateTime.Today - start).Days;
            return start.AddDays(rnd.Next(range)).ToString("dd-MM-yyyy");
        }

        public string GetDateYYYYMMDD()
        {
            DateTime start = new DateTime(1995, 1, 1);
            int range = (DateTime.Today - start).Days;
            return start.AddDays(rnd.Next(range)).ToString("yyyy-MM-dd");
        }

        private DateTime internalDateCal(DateTime from, DateTime to)
        {
            DateTime start = from;
            int range = (to - start).Days;
            return start.AddDays(rnd.Next(range));
        }

        public string GetDateDDMMYYYYByGivenDateRange(DateTime from, DateTime to)
        {
            return internalDateCal(from, to).ToString("dd-MM-yyyy");
        }

        public string GetDateYYYYMMDDByGivenDateRange(DateTime from, DateTime to)
        {
            return internalDateCal(from, to).ToString("yyyy-MM-dd");
        }

        public string GetDateDDMMYYYYByGivenAge(byte MinimumAge)
        {
            DateTime to = DateTime.Today.AddYears((-1) * MinimumAge);
            DateTime from = to.AddYears((-1) * MinimumAge);
            return internalDateCal(from, to).ToString("dd-MM-yyyy");
        }

        public int GetThreeDigitNumber()
        {
            return rnd.Next(3);
        }

        public int GetFourDigitNumber()
        {
            return rnd.Next(4);
        }

        public int GetFiveDigitNumber()
        {
            return rnd.Next(5);
        }

        public int GetSixDigitNumber()
        {
            return rnd.Next(6);
        }

        public int GetIntegerByGivenRange(int minValue, int maxValue)
        {
            return rnd.Next(minValue, maxValue);
        }

        public string GetUKPostCode()
        {
            var codes = "NN8 3RP,SK9 4LX,BT38 8QG,UB18 9US,DN33 1LY,LS25 6NW,DN8 4QF,RG4 7QN,SE12 0NA,WF2 7QT,N1 0NZ,N1 0PA,N1 0PB,N1 0PD,N1 0PE,N1 0PF,N1 0PG,0PHN1 0PJ,N1 0PL,N1 0PN";
            var allcodes = codes.Split(',');
            return allcodes[rnd.Next(20)];
        }

        public string GetStringByGivenLength(int length, bool IsLowerCase)
        {
            StringBuilder RandStr = new StringBuilder(length);
            int Start = (IsLowerCase) ? 97 : 65;
            for (int i = 0; i < length; i++)
                RandStr.Append((char)(26 * rnd.NextDouble() + Start));

            return RandStr.ToString();
        }

        public string GetAlphaNumberic(int minLength, int maxLength)
        {
            var sb = new StringBuilder();
            var stringLength = rnd.Next(minLength, maxLength);
            for (int i = 0; i < stringLength; i++)
                sb.Append(AlphaNumericCharacters[rnd.Next(0, AlphaNumericCharacters.Length - 1)]);
            return sb.ToString();
        }

        public string GetStringWithSpecialCharacters(int length)
        {
            return CreatePassword(length);
        }

        public List<int> GetAllIntergersBetweenGivenNumbers(int From, int To)
        {
            return Enumerable.Range(From, To).OrderBy(x => rnd.Next()).ToList();
        }

        // GetAllIntergersBetweenTwoNumberNumbers(1-10). will give all numbers between 1 to 10
        public List<int> GetAllIntergersBetweenTwoNumberNumbers(string Range)
        {
            var rangeArr = Range.Split('-');
            int From = Convert.ToInt32(rangeArr[0]);
            int To = Convert.ToInt32(rangeArr[1]);
            return GetAllIntergersBetweenGivenNumbers(From, To);
        }

        public List<int> ConvertStringToIntegerArrray(string CommaSeparateInteger, char Delimit)
        {
            return (CommaSeparateInteger.Split(Delimit).Select(t => Convert.ToInt32(t)).ToList());
        }

        public List<int> ConvertStringToIntegerArrray(string GivenString)
        {
            List<int> arr = new List<int>();
            if (GivenString.Contains(","))
                arr = ConvertStringToIntegerArrray(GivenString, ',');
            else if (GivenString.Contains("-"))
                arr = GetAllIntergersBetweenTwoNumberNumbers(GivenString);
            else
                arr.Add(Convert.ToInt32(GivenString));
            return arr;
        }

        public bool IsTestCaseMatching(string InputData, string Qualifier)
        {
            var res = ConvertStringToIntegerArrray(InputData);
            return (res.FirstOrDefault(t => t == Convert.ToInt32(Qualifier)) != 0);
        }

        public string CreatePassword(int length)
        {
            string lower = "abcdefghijklmnopqrstuvwxyz";
            string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string number = "1234567890";
            var middle = length / 2;
            var res = new StringBuilder();
            while (0 < length--)
            {
                if (middle == length)
                    res.Append(number[rnd.Next(number.Length)]);
                else if (middle - 1 == length)
                    res.Append(PunctuationCharacters[rnd.Next(PunctuationCharacters.Length)]);
                else
                {
                    if (length % 2 == 0)
                        res.Append(lower[rnd.Next(lower.Length)]);
                    else
                        res.Append(upper[rnd.Next(upper.Length)]);
                }
            }
            return res.ToString();
        }
    }
}