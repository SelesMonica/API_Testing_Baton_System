﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace TU.DE.Specflow.HelperUtilities
{
    // Partial Exception will be used to see only the expected error message without over info
    // it will not show the Stack trace entries

    [Serializable]
    public class TUSpecflowPartialException : Exception
    {
        private readonly string _excludeFromStackTrace;

        public TUSpecflowPartialException(string ErrorMessage)
        {
            _excludeFromStackTrace = ErrorMessage;
        }

        //without these constructor deserailiation will fails
        protected TUSpecflowPartialException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Message
        {
            get
            {
                return _excludeFromStackTrace;
            }
        }

        // Hide the stack trace for partial exception. show only necessary error message
        public override string StackTrace
        {
            get
            {
                return Message.Replace(_excludeFromStackTrace, "");
            }
        }

        // Hide the error source entries
        public override string Source
        {
            get
            {
                return "";
            }
        }
    }

    // Full Exception will be used to see the error with more info (Ex. in Which function error occured, stack entries)
    // it will show the Stack trace entries
    [Serializable]
    public class TUSpecflowFullException : Exception
    {
        private readonly string _excludeFromStackTrace;

        public TUSpecflowFullException(string ErrorMessage)
        {
            _excludeFromStackTrace = ErrorMessage;
        }

        //without these constructor deserailiation will fails
        protected TUSpecflowFullException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        // Show all the stack trace for full exception
        public override string StackTrace
        {
            get
            {
                List<string> stackTrace = new List<string>();
                stackTrace.AddRange(base.StackTrace.Split(new string[] { Environment.NewLine }, StringSplitOptions.None));
                stackTrace.RemoveAll(x => x.Contains(_excludeFromStackTrace));
                return string.Join(Environment.NewLine, stackTrace.ToArray());
            }
        }

        public override string Message
        {
            get
            {
                return _excludeFromStackTrace;
            }
        }
    }
}