﻿/*
 *  this class used to handled the error
 *  if any error it will retry the particular error until the retry limit is exceeded
 *  the retry count and retry interval configuration will be in app.config
 */

using System;
using System.Collections.Generic;
using System.Threading;

namespace TU.DE.Specflow.HelperUtilities
{
    public class RetryHelper
    {
        // Do an Event without return type
        public void DoEvent(Action action)
        {
            DoEvent<object>(() =>
            {
                action();
                return null;
            });
        }

        // Do an Event with return type <T>
        public T DoEvent<T>(Func<T> action)
        {
            var exceptions = new List<Exception>();
            for (int attempted = 0; attempted < UKEnvironment.Specflow.Variables.Env_ErrorRetryCountUI; attempted++)
            {
                try
                {
                    if (attempted > 0)
                    {
                        Thread.Sleep((int)UKEnvironment.Specflow.Variables.Env_ErrorRetryIntervalMs);
                    }
                    return action();
                }
                catch (Exception ex)
                {
                    exceptions.Add(ex);
                }
            }
            throw new AggregateException(exceptions);
        }
    }
}