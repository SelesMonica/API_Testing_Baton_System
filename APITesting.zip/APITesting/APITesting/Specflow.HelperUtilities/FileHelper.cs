﻿using System;

namespace TU.DE.Specflow.HelperUtilities
{
    public static class FileHelper
    {
        public static string GetDocuAuthImageDirectory()
        {
            return AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug", "").Replace("\\TestSuite", "") + "\\DocAuthImages\\";
        }
        public static string GetAIDCloudTestDataDirectory()
        {
            return AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug", "").Replace("\\TestSuite", "") + "\\AIDCloudTestData\\";
        }
    }
}