﻿/*
 *  this class will help you to convert the specflow table to objects or collections
 */

using System;
using System.Data;
using System.Reflection;

namespace TU.DE.Specflow.HelperUtilities
{
    public static class SpecFlowTableExtensions
    {
        public static T CreateInstance<T>(dynamic row) where T : new()
        {
            var Headers = row.Keys;
            DataTable dataTable = new DataTable();
            int headerCellCount = row.Count;
            var dataRow = dataTable.NewRow();
            for (int i = 0; i < headerCellCount; i++)
            {
                string columnName = Headers[i];
                Type columnType = "string".GetType();
                dataTable.Columns.Add(columnName, columnType);
            }
            for (int i = 0; i < headerCellCount; i++)
            {
                string columnName = Headers[i];
                dataRow[columnName] = Convert.ChangeType(row[i], "string".GetType());
            }
            return CreateItemRow<T>(dataRow);
        }

        private static T CreateItemRow<T>(DataRow row) where T : new()
        {
            T item = new T();
            SetItemFromRow(item, row);
            return item;
        }

        private static void SetItemFromRow<T>(T item, DataRow row) where T : new()
        {
            foreach (DataColumn c in row.Table.Columns)
            {
                PropertyInfo p = item.GetType().GetProperty(c.ColumnName);
                if (p != null && row[c] != DBNull.Value)
                    p.SetValue(item, row[c], null);
            }
        }
    }
}