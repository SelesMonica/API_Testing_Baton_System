﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace TU.DE.Specflow.HelperUtilities
{
    public static class JsonHelper
    {
        public static string SerializeToJson(dynamic data)
        {
            return JsonConvert.SerializeObject(data);
        }

        public static T DeserializeFromJson<T>(string data)
        {
            try
            {
                return JsonConvert.DeserializeObject<T>(data);
            }
            catch
            {
                return default;
            }
        }
        public static string BeginReadFile(string filename)
        {
            var dirPath = Assembly.GetExecutingAssembly().Location.Replace("\\bin\\Debug", "").Replace("TU.DE.Specflow.HelperUtilities.dll", "");
            return File.ReadAllText(dirPath + filename);
        }

        public static List<T> ConvertJArrayToGenericList<T>(JArray data)
        {
            try
            {
                return data.ToObject<List<T>>();
            }
            catch
            {
                return default;
            }
        }
    }
}