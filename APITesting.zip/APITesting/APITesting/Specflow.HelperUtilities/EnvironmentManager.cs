﻿using System.Configuration;

namespace Specflow.HelperUtilities
{

    public class ApiEnvironment
    {
        private static EnvironmentManager _environmentManager;
        private const string Environment = "Environment"; // App Settings environment key

        protected ApiEnvironment()
        {
        }


        public static EnvironmentManager Specflow
        {
            get
            {
                if (_environmentManager != null)
                    return _environmentManager;
                else
                    return _environmentManager = ConfigurationManager.GetSection(ConfigurationManager.AppSettings[Environment].ToString()) as EnvironmentManager;
            }
        }


        public static string ReadEnvironmentVariables(string VairableName)
        {
            VairableName = VairableName.Replace("'", "");
            return System.Convert.ToString(Specflow.Variables.GetType().GetProperty(VairableName)?.GetValue(Specflow.Variables, null));
        }
    }


    public sealed class SpecflowEnvironmentSettings : ConfigurationElement
    {
        internal SpecflowEnvironmentSettings()
        { }


        private const string VariableName = "Variables";


        [ConfigurationProperty("Env_ApiUserId", IsRequired = true)]
        public string Env_ApiUserId
        {
            get
            {
                return (string)this["Env_ApiUserId"];
            }
        }

        [ConfigurationProperty("Env_ApiPassword", IsRequired = true)]
        public string Env_ApiPassword
        {
            get
            {
                return (string)this["Env_ApiPassword"];
            }
        }

        [ConfigurationProperty("Env_PortalRegister")]
        public string Env_PontServiceTokenURL
        {
            get
            {
                return (string)this["Env_PortalRegister"];
            }
        }

        [ConfigurationProperty("Env_PortalURL")]
        public string Env_PontNewApplicationSubmitURL
        {
            get
            {
                return (string)this["Env_PortalURL"];
            }
        }


        [ConfigurationProperty("Env_ErrorRetryCountUI", DefaultValue = "3", IsRequired = true)]
        public int Env_ErrorRetryCountUI
        {
            get
            {
                return (int)this["Env_ErrorRetryCountUI"];
            }
        }

        [ConfigurationProperty("Env_ErrorRetryIntervalMs", DefaultValue = "7000", IsRequired = true)]
        public long Env_ErrorRetryIntervalMs
        {
            get
            {
                return (long)this["Env_ErrorRetryIntervalMs"];
            }
        }


    }
}

